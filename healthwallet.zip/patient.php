<html>
<title>Welocome to healthwallet</title>
<head>
<style>
.divleft
{
background-color:red;	
width:10%;	
height:100%;	
border:1px solid;
}
.divright
{
background-color:yellow;		
height:100%;
width:90%;	
}
.tbl
{
width:100%;	
	
}
</style>
</head>
<body>
<table class="tbl">
<tr><td>
<div class="divleft">
<a href="#" >yogesh</a></br>
<a href="#" >vishvambhar</a></br>
<a href="#" >jadhav</a></br>
<a href="#" >chatra borgaon</a></br>
<a href="#" >tq. majalgaon</a></br>
</div></td><td>
<div class="divright">
rellr4

</div>
</td></tr></table>

</body>
</html>