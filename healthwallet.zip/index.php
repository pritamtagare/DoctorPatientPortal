<html>
<head><title>healthwallet</title>
<link rel="styleshhet" href="css/main.css"/>
</head>
<body class="mainbody">
<?php require 'header.php'; ?>
<div>
<?php include 'middiv.php'; ?>
<?php require("membership.php"); ?>
</div>
<?php require('footer.php');?>
</body>
</html>