<html>
<title>healthwallet</title>
<body>
<?php require "header.php";?>
<div>
<?php require "signup.html";?>
</div>
<?php require "footer.php";?>

</body>
</html>