<html>
<head>
<style>
.divlgn
{
background-image:url("images/midbg.png");	
height:100%;
width:auto%;
text-align:center;
padding:12% 16%;
}	
</style>
</head>
<body>
<?php
require("header.php");
?>
<div class="divlgn">

<?php require("login.html");?>
</div>
<?php
require("footer.php");
?>
</body>
</html>