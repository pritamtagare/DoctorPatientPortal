<?php
echo '<footer id="myFooter">
        <div class="footer">
		<div class="footer-copyright">
         <p>&copy; 2017 Copyright healthwallet </p>
		</div>
		</div>
    </footer>
</body>
</html>'
?>
