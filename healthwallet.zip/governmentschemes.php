<html>
<head>
<link rel="styleshhet" href="css/main.css"/>
</head>
<body>
<?php require 'header.php'; ?>


<?php require('footer.php');?>
</body>
</html>