<html>
<head>
<link href="css/mystyle2.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/footer.css" rel="stylesheet">
<link href="css/gov.css" rel="stylesheet">
<style>
.nav1
{
background-image:url("images/14.jpg");

}
iframe
{
border:5px solid gray;
margin-left:0px;
padding-left:0px;
overflow:hidden;	
}
</style>
</head>
<body>
<?php require("header.php"); ?>
<div class="conta">
<nav class="nav1">
  <div class="divnav">
  <ul type="none">
    <li><a class="anchr" target="frame1" href="rsby.html">Rashtiya Swasthiya Bima Yojana</a></li><br>
    <li><a class="anchr" target="frame1" href="aaby.html">Aam Aadmi Bima Yojana</a></li><br>
    <li><a class="anchr" target="frame1" href="cghs.html">Central Government Health Scheme</a></li><br>
	<li><a class="anchr" target="frame1" href="esis.html">Employment State Insurance Scheme </a></li><br>
    <li><a class="anchr" target="frame1" href="jby.html">Janashree Bima Yojana</a></li>
    
  </ul>
  </div><br><Br><img src="images/gov.jpg" height="300px" width="400px"><br>
  </nav>
  
<article>


	<iframe name="frame1" frame src="rsby.html" height="100%" width="100%">
                          

						  
						  </iframe>						  


</article>
</div>
<?php require("footer.php"); ?>
</body>
</html>
