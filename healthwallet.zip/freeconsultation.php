<html>
<head>
<link href="css/mystyle2.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/footer.css" rel="stylesheet">
<link href="css/gov.css" rel="stylesheet">
<style>
.nav1
{
background-image:url("images/14.jpg");

}
iframe
{
border:5px solid gray;
margin-left:0px;
padding-left:0px;
overflow:hidden;	
}
</style>

</head>
<body>
<?php require("header.php"); ?>
<div class="conta">
<nav class="nav1" >
  <div class="divnav">
  <ul type="none">
    <li><a class="anchr" target="frame1" href="healthytips.html"> Healthy Living </a></li><br>
    <li><a class="anchr" target="frame1" href="pregnancytips.html">Pregnancy Tips</a></li><br>
    <li><a class="anchr" target="frame1" href="typhoid.html">Typhoid Vaccine</a></li><br>
	<li><a class="anchr" target="frame1" href="yoga.html">About Yoga </a></li><br>
    <li><a class="anchr" target="frame1" href="rabies.html">Rabies</a></li></br>
     <li><a class="anchr" target="frame1" href="polio.html">Polio</a></li>
  </ul>
  
  </div><br><br>
  <img src="images/vaccine.jpg" height="100%" width="100%"></nav>
<article>


	<iframe name="frame1" frame src="healthytips.html" height="100%" width="100%">
                          

						  
						  </iframe>						  


</article>
</div>
</body>
<?php require("footer.php"); ?>
</html>
