<?php
echo '<html>
<head>
<title>healthwallet</title>
<!-- Styles -->
<link href="css/mystyle2.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/footer.css" rel="stylesheet">
</head>
<body>
<!--******************** NAVBAR ********************-->
<div>
  <div class="navbar navbar-inverse navbar-fixed-top">
    <div class="navbar-inner">
      <div class="container">
        <div class="logo">
          <h1 class="brand"><a>healthwallet</a></h1>
		  </div>
      </div>
      <!-- /.container -->
    </div>
	<!-- /.navbar-inner -->
	
  </div>
  <!-- /.navbar -->
</div>';
?>
