<html>
<head>
<style>
.span3
{
margin-left:250px;	
}
</style>
</head>
<body>
<section id="membership" class="single-page scrollblock">
  <div class="container">
    <h1 align="center">Registration For</h1>
	</br></br>
    <!-- Four columns -->
    <div class="row">
      <div class="span3">
        <div class="align">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/Membership.png"> </div>
        <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Patient </h2></br>
        <p>Patient have to registered to store the medical records and to get the other 
		facilities like queries,health tips. for registration click here.... </p>
		</br>
        <p class="sign up"><a class="ah" href="signup.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign up</a></p>
      </br>
	  </div>
      <!-- /.span3 -->
      <div class="span3">
        <div class="align">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/Membership.png"></div>
        <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Doctor</h2>
		</br> 
        <p>Doctor have to registered to view patients records,to answer the queries, 
		as well as to create new report, he can also suggest some medical tips. for registrtation click here....</p>
        <p class="sign up"><a class="ah" href="signup.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign up</a></p>
      </br>
	  </div>
    </div>
  </div>
</section>
</body>
</html> 
